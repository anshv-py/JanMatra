
// Background Service Worker for Regulation Feedback Collector (MV3)

let extensionState = {
    settings: {
        // Server Configuration  
        analysisServerUrl: 'https://your-analysis-website.com',
        apiEndpoint: '/api/analyze',
        
        // Collection Settings
        autoCollect: true,
        batchSize: 50,
        collectMetadata: true,
        
        // Export Settings
        exportFormat: 'json',
        includeMetadataInExport: true,
        
        // Data Management
        storageLimit: 100, // MB
        
        // Portal Configuration
        enabledPortals: {
            mygov: true,
            govuk: true,
            citizenspace: true
        }
    },
    stats: { collected: 0, pending: 0, synced: 0 }
};

const SUPPORTED_PORTALS = {
    'mygov.in': {
        name: 'MyGov India',
        selectors: {
            feedbackForm: '.feedback-form, #feedback, [data-feedback], .comment-form',
            comments: '.comment, .feedback-item, .response, .user-comment',
            commentText: '.comment-text, .feedback-content, .comment-body, p',
            author: '.author, .user-name, .commenter, .comment-author',
            timestamp: '.date, .timestamp, .time, [data-time], .comment-date',
            votes: '.votes, .rating, .score, .like-count'
        }
    },
    'gov.uk': {
        name: 'UK Government Consultations',
        selectors: {
            feedbackForm: '.consultation-form, .response-form, .govuk-form',
            comments: '.consultation-response, .comment, .response-item',
            commentText: '.response-text, .comment-content, .govuk-body',
            author: '.respondent, .author, .response-author',
            timestamp: '.published-date, .submission-date, .govuk-date',
            votes: '.support-count, .rating, .vote-count'
        }
    },
    'delib.net': {
        name: 'Citizen Space',
        selectors: {
            feedbackForm: '.cs-form, .consultation-form, .response-form',
            comments: '.response, .consultation-response, .comment',
            commentText: '.response-content, .answer-text, .comment-text',
            author: '.respondent-info, .author, .response-author',
            timestamp: '.response-date, .submitted-date, .comment-date',
            votes: '.rating, .votes, .support-count'
        }
    },
    generic: {
        name: 'Generic Portal',
        selectors: {
            feedbackForm: 'form, .form, .feedback, .comment-form',
            comments: '.comment, .response, .feedback, .post, .review',
            commentText: 'p, .text, .content, .body, .message',
            author: '.author, .name, .user, .by',
            timestamp: '.date, .time, .timestamp, .posted',
            votes: '.votes, .rating, .score, .likes'
        }
    }
};

chrome.runtime.onInstalled.addListener(async () => {
    await initializeStorage();
});

async function initializeStorage() {
    try {
        const result = await chrome.storage.local.get(['settings', 'stats']);
        
        if (!result.settings) {
            await chrome.storage.local.set({ settings: extensionState.settings });
        } else {
            extensionState.settings = { ...extensionState.settings, ...result.settings };
        }
        
        if (!result.stats) {
            await chrome.storage.local.set({ stats: extensionState.stats });
        } else {
            extensionState.stats = result.stats;
        }
        
        console.log('Background script initialized with settings:', extensionState.settings);
    } catch (e) {
        console.error('Storage init error', e);
    }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
        case 'PING':
            sendResponse({ ok: true });
            break;

        case 'GET_STATS':
            sendResponse({ success: true, data: extensionState.stats });
            break;

        case 'GET_PORTAL_CONFIG':
            try {
                const tabUrl = sender?.tab?.url || message.url || '';
                const domain = tabUrl ? new URL(tabUrl).hostname : '';
                const cfg = getPortalConfig(domain);
                sendResponse({ success: true, data: cfg });
            } catch (e) {
                sendResponse({ success: true, data: SUPPORTED_PORTALS.generic });
            }
            break;

        case 'START_COLLECTION':
            startCollection(sender?.tab)
                .then(() => sendResponse({ success: true }))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;

        case 'COLLECT_FEEDBACK':
            handleFeedbackCollection(message.data, sender?.tab || { url: '', title: '' })
                .then(d => sendResponse({ success: true, data: d }))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;

        case 'GET_COLLECTED_DATA':
            getCollectedData()
                .then(d => sendResponse({ success: true, data: d }))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;

        case 'SEND_TO_SERVER':
            sendDataToAnalysisServer(message.data)
                .then(res => sendResponse({ success: true, data: res }))
                .catch(err => sendResponse({ success: false, error: err.message }));
            return true;

        case 'UPLOAD_PDF':
            processPdfFile(message.fileData, message.fileName, message.fileSize)
                .then(d => sendResponse({ success: true, data: d }))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;

        case 'UPDATE_SETTINGS':
            updateSettings(message.settings)
                .then(() => sendResponse({ success: true, message: 'Settings updated' }))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;

        case 'CLEAR_ALL_DATA':
            clearAllData()
                .then(() => sendResponse({ success: true, message: 'All data cleared' }))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;

        case 'TEST_COLLECTION':
            testCollection()
                .then(res => sendResponse({ success: true, data: res }))
                .catch(err => sendResponse({ success: false, error: err.message }));
            return true;

        case 'DATA_CLEARED':
            // Handle notification from options page
            extensionState.stats = { collected: 0, pending: 0, synced: 0 };
            sendResponse({ success: true });
            break;

        default:
            sendResponse({ success: false, error: 'Unknown message type' });
    }
});

async function startCollection(tab) {
    if (!tab) throw new Error('No active tab found');
    
    console.log('Starting collection on tab:', tab.url);
    
    // Inject content script if not already present
    try {
        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
        });
        
        // Also inject CSS
        await chrome.scripting.insertCSS({
            target: { tabId: tab.id },
            files: ['content.css']
        });
    } catch (e) {
        console.warn('Content script injection failed:', e);
    }

    // Send start message to content script
    try {
        await chrome.tabs.sendMessage(tab.id, { type: 'START_COLLECTION' });
    } catch (e) {
        console.warn('Failed to send start message:', e);
    }
}

async function handleFeedbackCollection(feedbackData, tab) {
    const enriched = {
        ...feedbackData,
        collectionId: generateId(),
        timestamp: new Date().toISOString(),
        sourceUrl: tab?.url || '',
        sourceTitle: tab?.title || '',
        portalType: getPortalType(tab?.url || ''),
        collectedBy: 'extension'
    };

    // Check for duplicates
    if (await isDuplicateGlobally(enriched)) {
        console.log('Duplicate feedback detected, skipping:', enriched.text?.slice(0, 50));
        return enriched; // Skip duplicates
    }

    await storeCollectedData(enriched);
    extensionState.stats.collected += 1;
    extensionState.stats.pending += 1;
    await chrome.storage.local.set({ stats: extensionState.stats });

    console.log('Feedback collected:', enriched.collectionId);
    return enriched;
}

async function getCollectedData() {
    const result = await chrome.storage.local.get(null);
    const data = [];

    for (const [k, v] of Object.entries(result)) {
        if (k.startsWith('feedback-') && v && typeof v === 'object') {
            data.push(v);
        }
    }

    data.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    console.log('Retrieved collected data:', data.length, 'items');
    return data;
}

async function sendDataToAnalysisServer(data) {
    const serverUrl = extensionState.settings.analysisServerUrl;
    const endpoint = extensionState.settings.apiEndpoint;
    
    if (!serverUrl) {
        throw new Error('Analysis server URL not configured. Please set it in extension options.');
    }

    const url = serverUrl.replace(/\/$/, '') + endpoint;
    
    // Prepare payload
    const payload = {
        timestamp: new Date().toISOString(),
        source: 'regulation_feedback_extension',
        version: '1.0.0',
        count: data.length,
        data: data.map(item => ({
            id: item.collectionId || item.id,
            text: item.text || '',
            author: item.author || 'Anonymous',
            portal: item.portalType || 'Unknown',
            url: item.sourceUrl || '',
            timestamp: item.timestamp || new Date().toISOString(),
            metadata: {
                title: item.sourceTitle || '',
                votes: item.votes || 0,
                sentiment: item.sentiment || null,
                category: item.category || null,
                stableId: item.stableId || null
            }
        }))
    };

    console.log('Sending data to analysis server:', url, 'Items:', data.length);
    
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Extension-Version': '1.0.0',
                'X-Data-Source': 'regulation-feedback-collector',
                'User-Agent': 'RegulationFeedbackCollector/1.0.0'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            let errorMessage = `Server error ${response.status}: ${response.statusText}`;
            try {
                const errorData = await response.text();
                if (errorData) errorMessage += ` - ${errorData}`;
            } catch (e) {
                // Ignore parsing errors
            }
            throw new Error(errorMessage);
        }

        let result;
        try {
            result = await response.json();
        } catch (e) {
            result = { 
                message: 'Data sent successfully', 
                status: 'received',
                received_count: data.length 
            };
        }

        // Update stats
        extensionState.stats.synced += data.length;
        extensionState.stats.pending = Math.max(0, extensionState.stats.pending - data.length);
        await chrome.storage.local.set({ 
            stats: extensionState.stats,
            lastSync: {
                timestamp: new Date().toISOString(),
                count: data.length,
                server: serverUrl,
                status: 'success',
                response: result
            }
        });

        console.log('Data sent successfully to analysis server:', result);
        return result;

    } catch (error) {
        console.error('Failed to send data to server:', error);
        
        // Store failed sync info
        await chrome.storage.local.set({
            lastSync: {
                timestamp: new Date().toISOString(),
                count: data.length,
                server: serverUrl,
                status: 'failed',
                error: error.message
            }
        });
        
        throw error;
    }
}

async function processPdfFile(fileData, fileName, fileSize) {
  try {
    // 1. Get access token
    const tokenResp = await fetch("https://ims-na1.adobelogin.com/ims/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: "8f210009ab144df883cf6aa7810874a8", // ← Replace with your real credentials
        client_secret: "p8e-pln1QRVZ_kSudu1mNBfMPpJbncpeA4D8", // ← Replace with your real credentials
        grant_type: "client_credentials",
        scope: "openid,AdobeID,read_organizations"
      })
    });

    if (!tokenResp.ok) {
      throw new Error(`Token request failed: ${tokenResp.status} - ${await tokenResp.text()}`);
    }

    const tokenData = await tokenResp.json();
    const accessToken = tokenData.access_token;

    if (!accessToken) {
      throw new Error("Failed to get Adobe access token - check your credentials");
    }

    // 2. Upload PDF to Adobe Cloud Storage first
    const base64 = fileData.includes(',') ? fileData.split(',')[1] : fileData;
    const binary = atob(base64);
    const array = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      array[i] = binary.charCodeAt(i);
    }
    const pdfBlob = new Blob([array], { type: "application/pdf" });

    // Upload to Adobe's asset storage
    const uploadResp = await fetch("https://pdf-services.adobe.io/assets", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "x-api-key": "8f210009ab144df883cf6aa7810874a8", // ← Same as client_id
        "Content-Type": "application/pdf"
      },
      body: pdfBlob
    });

    if (!uploadResp.ok) {
      const errorText = await uploadResp.text();
      throw new Error(`Adobe upload failed: ${uploadResp.status} - ${errorText}`);
    }

    const uploadData = await uploadResp.json();
    const assetId = uploadData.assetID;

    // 3. Create extraction job
    const jobResp = await fetch("https://pdf-services.adobe.io/operation/extractpdf", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "x-api-key": "8f210009ab144df883cf6aa7810874a8",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        assetID: assetId,
        extractOption: {
          extractTextData: true,
          extractMetaData: true
        }
      })
    });

    if (!jobResp.ok) {
      const errorText = await jobResp.text();
      throw new Error(`Adobe job creation failed: ${jobResp.status} - ${errorText}`);
    }

    const jobLocation = jobResp.headers.get("location");

    // 4. Poll for completion
    let resultUrl = null;
    for (let i = 0; i < 20; i++) {
      await new Promise(r => setTimeout(r, 3000));
      
      const statusResp = await fetch(jobLocation, {
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "x-api-key": "8f210009ab144df883cf6aa7810874a8"
        }
      });

      const statusData = await statusResp.json();
      
      if (statusData.status === "done") {
        resultUrl = statusData.asset.downloadUri;
        break;
      } else if (statusData.status === "failed") {
        throw new Error(`Adobe job failed: ${JSON.stringify(statusData)}`);
      }
    }

    if (!resultUrl) {
      throw new Error("Adobe extraction job timed out");
    }

    // 5. Download result
    const resultResp = await fetch(resultUrl, {
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "x-api-key": "8f210009ab144df883cf6aa7810874a8"
      }
    });

    const resultJson = await resultResp.json();

    // 6. Store result
    const processed = {
      id: generateId(),
      fileName,
      fileSize,
      uploadedAt: new Date().toISOString(),
      status: "processed",
      content: resultJson
    };

    await chrome.storage.local.set({ ["pdf-" + processed.id]: processed });
    return processed;

  } catch (err) {
    console.error("Adobe Extract error:", err);
    console.error("Error details:", err.message);
    throw err;
  }
}




async function simulateTextExtraction(fileName) {
    const samples = [
        'Executive Summary\n\nThis document outlines the proposed regulatory changes to improve citizen consultation processes...',
        'Policy Background\n\nThe current regulatory framework requires updates to better serve public interests...',
        'Implementation Guidelines\n\nThe following sections detail the implementation approach for the new consultation framework...',
        'Consultation Response\n\nWe appreciate the opportunity to provide feedback on these important policy changes...'
    ];
    
    return samples[Math.floor(Math.random() * samples.length)] + 
           `\n\nExtracted from: ${fileName}\nProcessed on: ${new Date().toISOString()}\nExtraction method: Simulated OCR`;
}

async function simulateMetadataExtraction(fileName) {
    return {
        title: fileName.replace(/\.pdf$/i, ''),
        author: 'Government Department',
        creator: 'PDF Creator Tool',
        producer: 'Document Processing System',
        creationDate: new Date(Date.now() - Math.random() * 30 * 24 * 3600 * 1000).toISOString(),
        modificationDate: new Date().toISOString(),
        pages: Math.floor(Math.random() * 50) + 5,
        language: 'en-US',
        keywords: ['regulation', 'consultation', 'policy', 'feedback']
    };
}

async function simulateStructureAnalysis() {
    return {
        headings: ['Executive Summary', 'Background', 'Proposed Changes', 'Implementation', 'Conclusion'],
        paragraphs: Math.floor(Math.random() * 100) + 20,
        tables: Math.floor(Math.random() * 8),
        images: Math.floor(Math.random() * 15),
        links: Math.floor(Math.random() * 25),
        sections: Math.floor(Math.random() * 10) + 3
    };
}

async function testCollection() {
    // Simulate collection test
    const testData = {
        text: 'This is a test feedback collection to verify the system is working correctly.',
        author: 'Test User',
        timestamp: new Date().toISOString(),
        portal: 'Test Portal',
        votes: 0
    };

    return {
        success: true,
        message: 'Collection test completed successfully',
        testData: testData,
        settings: extensionState.settings,
        supportedPortals: Object.keys(SUPPORTED_PORTALS)
    };
}

async function updateSettings(newSettings) {
    extensionState.settings = { ...extensionState.settings, ...newSettings };
    await chrome.storage.local.set({ settings: extensionState.settings });
    console.log('Settings updated:', extensionState.settings);
}

async function clearAllData() {
    const result = await chrome.storage.local.get(null);
    const keysToRemove = [];

    // Identify data keys (keep settings)
    Object.keys(result).forEach(key => {
        if (key.startsWith('feedback-') ||
            key.startsWith('pdf-') ||
            key === 'stats' ||
            key === 'syncQueue' ||
            key === 'lastSync' ||
            key === 'lastAnalysis') {
            keysToRemove.push(key);
        }
    });

    if (keysToRemove.length > 0) {
        await chrome.storage.local.remove(keysToRemove);
        console.log('Cleared data keys:', keysToRemove.length);
    }

    // Reset stats
    extensionState.stats = { collected: 0, pending: 0, synced: 0 };
    await chrome.storage.local.set({ stats: extensionState.stats });
}

async function storeCollectedData(data) {
    await chrome.storage.local.set({ ['feedback-' + data.collectionId]: data });
}

function getPortalConfig(domain) {
    if (!domain) return SUPPORTED_PORTALS.generic;
    
    for (const [key, cfg] of Object.entries(SUPPORTED_PORTALS)) {
        if (key !== 'generic' && domain.includes(key)) {
            return cfg;
        }
    }
    
    return SUPPORTED_PORTALS.generic;
}

function getPortalType(url) {
    try {
        const domain = new URL(url).hostname;
        for (const [key, cfg] of Object.entries(SUPPORTED_PORTALS)) {
            if (key !== 'generic' && domain.includes(key)) {
                return cfg.name;
            }
        }
    } catch (e) {
        console.warn('Error parsing URL for portal type:', url, e);
    }
    return 'Generic Portal';
}

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function normalizeTextForKey(s) {
    return (s || '').trim().replace(/\s+/g, ' ').slice(0, 160).toLowerCase();
}

async function isDuplicateGlobally(newItem) {
    const result = await chrome.storage.local.get(null);
    const newKey = newItem.stableId || '';
    const normNew = normalizeTextForKey(newItem.text);

    for (const [k, v] of Object.entries(result)) {
        if (!k.startsWith('feedback-') || !v || typeof v !== 'object') continue;
        
        // Check by stable ID
        if (newKey && v.stableId && v.stableId === newKey) return true;
        
        // Check by normalized text
        const normOld = normalizeTextForKey(v.text);
        if (normOld && normOld === normNew) return true;
    }
    
    return false;
}

// Keep service worker alive
chrome.runtime.onStartup.addListener(() => {
    console.log('Extension startup');
});

// Handle installation
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        console.log('Extension installed');
        chrome.runtime.openOptionsPage();
    } else if (details.reason === 'update') {
        console.log('Extension updated');
    }
});
