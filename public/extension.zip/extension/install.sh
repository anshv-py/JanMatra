#!/bin/bash

# Regulation Feedback Collector Extension Installer
# This script helps set up the Chrome extension for development

echo "🚀 Setting up Regulation Feedback Collector Extension..."

# Check if we're in the right directory
if [ ! -f "manifest.json" ]; then
    echo "❌ Error: manifest.json not found. Please run this script from the extension directory."
    exit 1
fi

echo "✅ Found extension files"

# Create icons directory if it doesn't exist
if [ ! -d "icons" ]; then
    mkdir icons
    echo "📁 Created icons directory"
fi

# Check Chrome installation
if command -v google-chrome &> /dev/null; then
    CHROME_CMD="google-chrome"
elif command -v chromium-browser &> /dev/null; then
    CHROME_CMD="chromium-browser"
elif command -v google-chrome-stable &> /dev/null; then
    CHROME_CMD="google-chrome-stable"
else
    echo "⚠️  Chrome not found. Please install Google Chrome or Chromium."
    echo "   You can still manually load the extension in Chrome."
fi

echo ""
echo "📋 Installation Instructions:"
echo "1. Open Chrome and go to chrome://extensions/"
echo "2. Enable 'Developer mode' (toggle in top right)"
echo "3. Click 'Load unpacked' button"
echo "4. Select this directory: $(pwd)"
echo "5. The extension will appear in your extensions list"
echo ""

if [ ! -z "$CHROME_CMD" ]; then
    echo "🔧 Quick setup option:"
    echo "   Run: $CHROME_CMD --load-extension=$(pwd)"
    echo ""
fi

echo "📖 For detailed instructions, see README.md"
echo "⚙️  Configure settings after installation via extension options page"
echo ""
echo "✨ Happy feedback collecting!"
