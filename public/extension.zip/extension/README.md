# Regulation Feedback Collector - Browser Extension

A powerful Chrome extension for collecting and analyzing public feedback on proposed regulations and amendments from government consultation portals.

## 🚀 Features

- **Automatic Portal Detection**: Recognizes government consultation websites including MyGov India, UK Government portals, and Citizen Space
- **Smart Content Extraction**: Intelligently extracts feedback, comments, and form data from web pages
- **Real-time Collection**: Live collection interface with progress tracking
- **Secure Authentication**: JWT-based authentication with your feedback analysis platform
- **Local Storage**: Secure local data storage with optional encryption
- **Automatic Sync**: Background synchronization with your analysis server
- **Export Capabilities**: Export collected data in multiple formats (JSON, CSV, Excel)
- **Privacy Compliant**: GDPR/DPDP compliant data handling

## 📦 Installation

### Option 1: Load Unpacked Extension (Development)

1. **Download the Extension Files**
   - Download all extension files to a folder on your computer
   - Ensure all files are in the same directory

2. **Open Chrome Extension Management**
   - Open Chrome browser
   - Navigate to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)

3. **Load the Extension**
   - Click "Load unpacked"
   - Select the folder containing the extension files
   - The extension should now appear in your extensions list

4. **Pin the Extension**
   - Click the puzzle piece icon in Chrome toolbar
   - Find "Regulation Feedback Collector"
   - Click the pin icon to keep it visible

### Option 2: Chrome Web Store (Coming Soon)

The extension will be available on the Chrome Web Store once approved.

## 🛠️ Setup & Configuration

### Initial Setup

1. **Click the Extension Icon**
   - Look for the 📊 icon in your Chrome toolbar
   - Click to open the popup

2. **Sign In**
   - Enter your account credentials
   - The extension will authenticate with your feedback platform

3. **Configure Settings**
   - Right-click the extension icon → "Options"
   - Or click the settings gear in the popup
   - Configure API URL, collection preferences, and sync settings

### API Configuration

In the extension settings, configure:

- **API Server URL**: Your feedback collection server endpoint
- **API Key**: Optional authentication key
- **Auto Collection**: Enable automatic collection on supported sites
- **Sync Interval**: How often to sync data with server

## 📋 Usage

### Automatic Collection

1. **Visit a Supported Portal**
   - Navigate to a government consultation website
   - The extension will automatically detect if the site is supported

2. **Start Collection**
   - Click the extension icon
   - Click "Start Collection" button
   - The collection interface will appear on the page

3. **Monitor Progress**
   - Watch real-time collection statistics
   - View detected feedback items
   - Check sync status

### Manual Collection

1. **Open Extension Popup**
   - Click the extension icon
   - View current page status

2. **Collection Controls**
   - Start/stop collection manually
   - Preview collected data
   - Export or sync data

### Data Management

1. **View Statistics**
   - Collected items count
   - Pending sync items
   - Successfully synced items

2. **Export Data**
   - Click "Export Data" in popup
   - Choose format (JSON, CSV, Excel)
   - Download collected feedback

3. **Sync to Server**
   - Automatic background sync
   - Manual sync via "Sync Now" button
   - View sync status and errors

## 🌐 Supported Portals

### Currently Supported

- **MyGov India** (`*.mygov.in`)
  - Government consultation platform
  - Feedback forms and public comments

- **UK Government** (`*.gov.uk`)
  - Official consultation portals
  - Public consultation responses

- **Citizen Space** (`*.delib.net`)
  - Delib's consultation platform
  - Community engagement portals

### Adding New Portals

The extension is designed to be easily extended for new consultation portals. Contact support for adding additional sites.

## ⚙️ Settings Reference

### API Configuration
- `API Server URL`: Base URL for your feedback API
- `API Key`: Optional authentication key for API requests

### Collection Settings
- `Auto Collection`: Automatically start collecting on supported sites
- `Batch Size`: Number of items to process in each batch (25-200)
- `Sync Interval`: Automatic sync frequency (1-30 minutes)
- `Collect Metadata`: Include additional context data

### Data Management
- `Storage Limit`: Maximum local storage before requiring sync (10-500 MB)
- `Encrypt Local Data`: Enable local data encryption (recommended)
- `Export Format`: Default format for data exports

### Privacy Settings
- All data is encrypted in transit and at rest
- Local data can be encrypted with user password
- Automatic data cleanup after successful sync
- No data is shared with third parties

## 🔧 Troubleshooting

### Common Issues

**Extension Not Loading**
- Ensure all files are in the same directory
- Check that manifest.json is present and valid
- Reload the extension in chrome://extensions/

**Collection Not Working**
- Verify the site is supported
- Check internet connection
- Try refreshing the page
- Check extension permissions

**Authentication Errors**
- Verify API server URL is correct
- Check credentials are valid
- Ensure API server is accessible
- Try logging out and back in

**Sync Failures**
- Check internet connection
- Verify API server is running
- Check API credentials
- Try manual sync

### Debug Mode

1. Right-click extension icon → "Inspect popup"
2. Check console for error messages
3. Go to chrome://extensions/ → Details → "Inspect views: background page"
4. Review background script console for errors

### Reset Extension

1. Open extension settings (Options page)
2. Click "Clear All Local Data"
3. Reset settings to defaults if needed
4. Re-authenticate with your account

## 📞 Support

### Getting Help

- **Documentation**: Full API documentation available at your platform dashboard
- **Support Email**: Contact your platform administrator
- **Bug Reports**: Report issues through your organization's support channels

### Feature Requests

Submit feature requests through your organization's feedback system or contact your system administrator.

## 🔒 Privacy & Security

### Data Handling
- All data is collected only from public consultation portals
- Personal information is handled according to GDPR/DPDP regulations
- Data is encrypted during transmission and storage
- Users can export or delete their data at any time

### Permissions
The extension requires these permissions:
- `storage`: Store settings and collected data locally
- `activeTab`: Access content on current tab for data extraction
- `scripting`: Inject collection scripts on consultation pages
- `identity`: Handle authentication with your platform
- `host_permissions`: Access supported government portals

### Security Features
- JWT-based authentication
- HTTPS-only communication
- Local data encryption options
- Automatic session management
- Secure token storage

## 📄 License

This extension is proprietary software. Contact your organization for licensing terms.

## 🔄 Version History

### v1.0.0 (Current)
- Initial release
- Support for MyGov India, UK Government, Citizen Space
- JWT authentication
- Local data storage and sync
- Export capabilities
- Settings management

---

For technical support, contact your system administrator or platform support team.
