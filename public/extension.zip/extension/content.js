// Content Script for Regulation Feedback Collector
// Adds Preview/Export/Send + PDF Upload to floater and attaches PDFs to feedback items

class FeedbackExtractor {
  constructor() {
    this.portalConfig = null;
    this.isCollecting = false;
    this.collectedData = [];
    this.extractionOverlay = null;
    this.observer = null;
    this._detectTimer = null;
    this.seenIds = new Set();      // per-page dedupe
    this.lastCollected = null;     // track last collected to attach PDFs
    this.init();
  }

  async init() {
    this.portalConfig = await this.getPortalConfig();
    this.createExtractionInterface();
    this.detectFeedbackElements();
    this.setupContentObserver();
  }

  async getPortalConfig() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'GET_PORTAL_CONFIG', url: location.href }, (response) => {
        resolve(response?.data || null);
      });
    });
  }

  isMyGov() {
    try { return /(^|\.)mygov\.in$/i.test(location.hostname); } catch { return false; }
  }
  getMyGovSelectors() {
    return {
      issueBody: '.group-issue .issue-content, .group_issue_content, .node .content, .content-section, .issue-desc, article',
      commentsList: '.commentlist, .comments, #comments, .suggestions, .feedback-list, .view, .views-element-container, .view-content',
      commentItem: '.comment, .comment-item, .views-row, li, .feedback-item, .comment-wrapper, .node-comment',
      commentText: '.comment-body, .comment-content, .content, .field-content, .comment__content, .field--name-comment-body, p',
      author: '.author, .username, .user-name, .comment-author, .submitted span, .views-field-name, .comment__author',
      timestamp: '.time, .timestamp, .submitted time, time, .views-field-created, .comment__time',
      votes: '.like, .vote, .rating, .upvote-count, .vote-count'
    };
  }

  // Get total submission count from page text
  getTotalSubmissions() {
    const text = document.body.textContent;
    const match = text.match(/Showing\s+(\d+)\s+Submission/i);
    return match ? parseInt(match[1], 10) : 0;
  }

  createExtractionInterface() {
    this.extractionOverlay = document.createElement('div');
    this.extractionOverlay.id = 'feedback-extraction-overlay';
    this.extractionOverlay.className = 'feedback-overlay';
    this.extractionOverlay.innerHTML = `
      <div class="feedback-panel">
        <div class="panel-header">
          <div class="panel-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14,2 14,8 20,8"></polyline>
            </svg>
            <span>Feedback Collector</span>
          </div>
          <button id="minimize-panel" class="panel-btn">−</button>
          <button id="close-panel" class="panel-btn">×</button>
        </div>
        <div class="panel-body">
          <div class="collection-stats">
            <div class="stat-item"><span class="stat-label">Total:</span><span id="total-count" class="stat-value">${this.getTotalSubmissions()}</span></div>
            <div class="stat-item"><span class="stat-label">Detected:</span><span id="detected-count" class="stat-value">0</span></div>
            <div class="stat-item"><span class="stat-label">Collected:</span><span id="collected-count" class="stat-value">0</span></div>
          </div>

          <div class="collection-controls">
            <button id="start-extraction" class="control-btn primary">Start Collection</button>
            <button id="stop-extraction" class="control-btn secondary" style="display:none;">Stop</button>
            <button id="clear-highlights" class="control-btn secondary">Clear Highlights</button>
          </div>

          <div class="floater-actions">
            <button id="floater-preview" class="control-btn secondary">Preview</button>
            <button id="floater-export" class="control-btn secondary">Export</button>
            <button id="floater-send" class="control-btn primary">Send to Server</button>
          </div>

          <div class="floater-actions">
            <button id="floater-attach-pdf" class="control-btn secondary">Attach PDF</button>
          </div>

          <div class="portal-info"><span class="portal-name">${this.portalConfig?.name || 'Generic Portal'}</span></div>
        </div>
      </div>
    `;
    this.makeDraggable(this.extractionOverlay);
    this.setupPanelEvents();
    document.body.appendChild(this.extractionOverlay);
  }

  setupPanelEvents() {
    const panel = this.extractionOverlay;
    panel.querySelector('#minimize-panel').addEventListener('click', () => {
      const body = panel.querySelector('.panel-body');
      const btn = panel.querySelector('#minimize-panel');
      if (body.style.display === 'none') { body.style.display = 'block'; btn.textContent = '−'; }
      else { body.style.display = 'none'; btn.textContent = '+'; }
    });
    panel.querySelector('#close-panel').addEventListener('click', () => {
      panel.remove(); this.clearAllHighlights(); if (this.observer) this.observer.disconnect();
    });
    panel.querySelector('#start-extraction').addEventListener('click', () => this.startCollection());
    panel.querySelector('#stop-extraction').addEventListener('click', () => this.stopCollection());
    panel.querySelector('#clear-highlights').addEventListener('click', () => this.clearAllHighlights());

    // Floater actions
    panel.querySelector('#floater-preview').addEventListener('click', () => this.showPreviewModal());
    panel.querySelector('#floater-export').addEventListener('click', () => this.quickExport());
    panel.querySelector('#floater-send').addEventListener('click', () => this.sendToServer());

    // PDF attach action
    panel.querySelector('#floater-attach-pdf').addEventListener('click', () => this.showPdfAttachModal());
  }

  makeDraggable(element) {
    const header = element.querySelector('.panel-header');
    let isDragging = false, initialX = 0, initialY = 0;
    header.addEventListener('mousedown', (e) => { isDragging = true; initialX = e.clientX - element.offsetLeft; initialY = e.clientY - element.offsetTop; });
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return; e.preventDefault();
      element.style.left = (e.clientX - initialX) + 'px';
      element.style.top = (e.clientY - initialY) + 'px';
    });
    document.addEventListener('mouseup', () => { isDragging = false; });
  }

  detectFeedbackElements() {
    const detected = new Set();

    if (this.isMyGov()) {
      const sel = this.getMyGovSelectors();
      document.querySelectorAll(sel.issueBody).forEach(el => { if (this.isGood(el)) detected.add(el); });
      document.querySelectorAll(sel.commentsList).forEach(list => {
        list.querySelectorAll(sel.commentItem).forEach(it => { if (this.isGood(it)) detected.add(it); });
      });
    } else {
      const selectors = this.portalConfig?.selectors || {};
      const elems = [
        ...document.querySelectorAll(selectors.comments || ''),
        ...document.querySelectorAll(selectors.feedbackForm || ''),
        ...document.querySelectorAll('article, .post, .entry, .item, .comment')
      ];
      elems.forEach(el => { if (this.isGood(el)) detected.add(el); });
    }

    const unique = Array.from(detected).filter(el => this.isValidFeedbackElement(el));
    const counter = document.querySelector('#detected-count');
    if (counter) counter.textContent = unique.length;

    unique.forEach((el, i) => {
      el.classList.add('feedback-detected');
      el.setAttribute('data-feedback-id', i);
      el.addEventListener('click', (e) => {
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          this.collectFromElement(el);
        }
      }, { capture: true });
    });
  }

  isGood(el) {
    const t = el?.textContent?.trim() || '';
    return t.length > 15;
  }

  isValidFeedbackElement(element) {
    const text = element?.textContent?.trim() || '';
    if (text.length < 10) return false;
    const invalid = ['nav', 'header', 'footer', 'menu', 'button', 'form'];
    return !invalid.includes(element.tagName.toLowerCase());
  }

  startCollection() {
    this.isCollecting = true;
    const startBtn = document.querySelector('#start-extraction');
    const stopBtn = document.querySelector('#stop-extraction');
    if (startBtn) startBtn.style.display = 'none';
    if (stopBtn) stopBtn.style.display = 'block';

    const detectedElements = document.querySelectorAll('.feedback-detected');
    detectedElements.forEach((element, index) => {
      setTimeout(() => { if (this.isCollecting) this.collectFromElement(element); }, index * 100);
    });
  }

  stopCollection() {
    this.isCollecting = false;
    const startBtn = document.querySelector('#start-extraction');
    const stopBtn = document.querySelector('#stop-extraction');
    if (startBtn) startBtn.style.display = 'block';
    if (stopBtn) stopBtn.style.display = 'none';
  }

  async collectFromElement(element) {
    try {
      const data = this.extractDataFromElement(element);
      if (!data || !data.text) return;

      // One-record-per-comment, de-dup by stable ID
      const stableId = this.makeStableId(element, data);
      if (this.seenIds.has(stableId)) return;
      this.seenIds.add(stableId);
      data.stableId = stableId;

      const resp = await this.sendToBackground('COLLECT_FEEDBACK', { data });
      element.classList.add('feedback-collected');
      this.collectedData.push({ ...data, collectionId: resp?.data?.collectionId || null });
      this.lastCollected = { ...data, collectionId: resp?.data?.collectionId || null };
      const collectedCountEl = document.querySelector('#collected-count');
      if (collectedCountEl) collectedCountEl.textContent = this.collectedData.length;
    } catch (error) {
      console.error('Error collecting from element:', error);
    }
  }

  makeStableId(element, data) {
    const idAttr = element.getAttribute('id') || element.dataset?.commentId || '';
    const anchor = element.querySelector('a[href*="#comment"], a[href*="comment-"]')?.getAttribute('href') || '';
    const textSample = (data.text || '').slice(0, 160);
    const key = [location.pathname, idAttr, anchor, textSample].join('|');
    let hash = 0;
    for (let i = 0; i < key.length; i++) hash = (hash * 31 + key.charCodeAt(i)) | 0;
    return `cm_${Math.abs(hash)}`;
  }

  extractDataFromElement(element) {
    const mygov = this.isMyGov();
    const sel = mygov ? this.getMyGovSelectors() : (this.portalConfig?.selectors || {});
    let textEl = null;
    if (mygov) {
      textEl = element.matches(sel.commentItem) ? (element.querySelector(sel.commentText) || element) : element;
    } else {
      textEl = element.querySelector(sel.commentText) || element;
    }
    const text = textEl?.textContent?.trim() || '';
    if (text.length < 10) return null;

    const authorEl = element.querySelector(sel.author);
    const tsEl = element.querySelector(sel.timestamp);
    const votesEl = element.querySelector(sel.votes);

    return {
      text,
      author: authorEl?.textContent?.trim() || 'Anonymous',
      timestamp: this.extractTimestamp(tsEl) || new Date().toISOString(),
      votes: this.extractVotes(votesEl) || 0,
      url: window.location.href,
      elementType: element.tagName.toLowerCase(),
      className: element.className,
      xpath: this.getElementXPath(element),
      extractedAt: new Date().toISOString(),
      site: location.hostname,
      totalSubmissions: this.getTotalSubmissions()
    };
  }

  extractTimestamp(el) {
    if (!el) return null;
    const dt = el.getAttribute?.('datetime') || el.getAttribute?.('data-time');
    if (dt) return dt;
    const t = el.textContent?.trim() || '';
    const m = t.match(/\d{1,2}\/\d{1,2}\/\d{4}|\d{4}-\d{2}-\d{2}/);
    if (m) return new Date(m[0]).toISOString();
    return null;
  }

  extractVotes(el) {
    if (!el) return 0;
    const t = el.textContent?.trim() || '';
    const n = t.match(/\d+/);
    return n ? parseInt(n[0], 10) : 0;
  }

  getElementXPath(element) {
    const paths = [];
    let current = element;
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      let selector = current.nodeName.toLowerCase();
      if (current.id) {
        selector += `[@id="${current.id}"]`;
        paths.unshift(selector);
        break;
      } else {
        const siblings = current.parentNode?.children;
        if (siblings && siblings.length > 1) {
          const index = Array.from(siblings).indexOf(current) + 1;
          selector += `[${index}]`;
        }
        paths.unshift(selector);
      }
      current = current.parentNode;
    }
    return paths.length ? `//${paths.join('/')}` : '';
  }

  setupContentObserver() {
    this.observer = new MutationObserver((mutations) => {
      let refresh = false;
      for (const m of mutations) {
        if (m.type === 'childList' && m.addedNodes?.length) { refresh = true; break; }
        if (m.type === 'attributes' && (m.target?.className || '').toString().includes('view')) { refresh = true; break; }
      }
      if (refresh) {
        clearTimeout(this._detectTimer);
        this._detectTimer = setTimeout(() => this.detectFeedbackElements(), 600);
      }
    });
    this.observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  }

  clearAllHighlights() {
    document.querySelectorAll('.feedback-detected, .feedback-collected').forEach(el => {
      el.classList.remove('feedback-detected', 'feedback-collected');
      el.removeAttribute('data-feedback-id');
    });
  }

  // Floater actions: Preview, Export, Send to Server
  async showPreviewModal() {
    try {
      const res = await this.sendToBackground('GET_COLLECTED_DATA', {});
      const data = res?.data || [];
      if (!data.length) return this.toast('No data available. Collect first.');
      const unique = this.dedupe(data);
      this.renderPreviewModal(unique);
    } catch (e) {
      this.toast('Preview failed: ' + e.message, true);
    }
  }

  quickExport() {
    this.sendToBackground('GET_COLLECTED_DATA', {}).then(res => {
      const data = res?.data || [];
      if (!data.length) return this.toast('No data to export. Collect first.');
      const unique = this.dedupe(data);
      this.downloadJSON(unique);
      this.toast('JSON exported');
    }).catch(e => this.toast('Export failed: ' + e.message, true));
  }

  async sendToServer() {
    try {
      const res = await this.sendToBackground('GET_COLLECTED_DATA', {});
      const data = res?.data || [];
      if (!data.length) return this.toast('No data to send. Collect first.');

      const unique = this.dedupe(data).map(it => ({
        id: it.stableId || it.collectionId,
        text: it.text,
        meta: { author: it.author, timestamp: it.timestamp, url: it.url, totalSubmissions: it.totalSubmissions }
      }));

      const modal = this.renderSendModal(unique.length);
      const fill = modal.querySelector('.progress-fill');
      const txt = modal.querySelector('.progress-text');
      fill.style.width = '35%'; txt.textContent = 'Contacting server...';

      const resp = await this.sendToBackground('SEND_TO_SERVER', { payload: unique, serverUrl: null });
      if (!resp?.success) throw new Error(resp?.error || 'Server error');

      fill.style.width = '100%'; txt.textContent = 'Done. Analysis received.';
      this.toast('Data sent to server.', false);
      setTimeout(() => modal.remove(), 1200);
    } catch (e) {
      this.toast('Send failed: ' + e.message, true);
    }
  }

  dedupe(items) {
    const unique = [];
    const seen = new Set();
    for (const it of items) {
      const key = (it.stableId || '') + '|' + (it.text || '').trim().slice(0, 160).toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      unique.push(it);
    }
    return unique;
  }

  renderPreviewModal(items) {
    this.removeModalById('floater-preview-modal');
    const rows = items.slice(0, 20).map((it, i) => `
      <div class="preview-row">
        <div class="preview-idx">${i + 1}</div>
        <div class="preview-text">${this.escapeHtml((it.text || '').slice(0, 400))}</div>
        <div class="preview-meta">
          <div>${this.escapeHtml(it.author || '')}</div>
          <div>${this.escapeHtml((it.timestamp || '').toString())}</div>
          <div>Total: ${it.totalSubmissions || 0}</div>
        </div>
      </div>
    `).join('');

    const modal = document.createElement('div');
    modal.id = 'floater-preview-modal';
    modal.className = 'floater-modal-overlay';
    modal.innerHTML = `
      <div class="floater-modal">
        <div class="floater-modal-header">
          <h3>Preview (${items.length})</h3>
          <button class="floater-close">&times;</button>
        </div>
        <div class="floater-modal-body">
          <div class="preview-list">${rows}${items.length > 20 ? '<div class="preview-more">...and more</div>' : ''}</div>
        </div>
        <div class="floater-modal-footer">
          <button class="floater-btn floater-secondary floater-close">Close</button>
          <button id="floater-dl-json" class="floater-btn floater-primary">Download JSON</button>
          <button id="floater-dl-csv" class="floater-btn floater-primary">Download CSV</button>
          <button id="floater-dl-xls" class="floater-btn floater-primary">Download Excel</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.querySelectorAll('.floater-close').forEach(b => b.addEventListener('click', () => modal.remove()));
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.remove(); });
    modal.querySelector('#floater-dl-json').addEventListener('click', () => { this.downloadJSON(items); modal.remove(); });
    modal.querySelector('#floater-dl-csv').addEventListener('click', () => { this.downloadCSV(items); modal.remove(); });
    modal.querySelector('#floater-dl-xls').addEventListener('click', () => { this.downloadExcel(items); modal.remove(); });
  }

  renderSendModal(count) {
    this.removeModalById('floater-send-modal');
    const modal = document.createElement('div');
    modal.id = 'floater-send-modal';
    modal.className = 'floater-modal-overlay';
    modal.innerHTML = `
      <div class="floater-modal">
        <div class="floater-modal-header">
          <h3>Send to Server</h3>
          <button class="floater-close">&times;</button>
        </div>
        <div class="floater-modal-body">
          <p>Sending ${count} items to sentiment analysis server...</p>
          <div class="floater-progress-bar"><div class="progress-fill" style="width: 20%;"></div></div>
          <p class="progress-text">Preparing request...</p>
        </div>
        <div class="floater-modal-footer">
          <button class="floater-btn floater-secondary floater-close">Close</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.querySelectorAll('.floater-close').forEach(b => b.addEventListener('click', () => modal.remove()));
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.remove(); });
    return modal;
  }

  // PDF attach: in-floater upload, process via background, attach to last collected
  showPdfAttachModal() {
    this.removeModalById('floater-pdf-modal');
    const modal = document.createElement('div');
    modal.id = 'floater-pdf-modal';
    modal.className = 'floater-modal-overlay';
    modal.innerHTML = `
      <div class="floater-modal">
        <div class="floater-modal-header">
          <h3>Attach PDF to Feedback</h3>
          <button class="floater-close">&times;</button>
        </div>
        <div class="floater-modal-body">
          <div class="file-drop-zone" id="floater-pdf-drop">
            <div class="drop-zone-content">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14,2 14,8 20,8"></polyline>
              </svg>
              <p>Drop PDF file here or click to browse</p>
              <p class="file-info">PDF up to 10MB</p>
            </div>
            <input type="file" id="floater-pdf-input" accept=".pdf" style="display:none;">
          </div>

          <div class="processing-options">
            <label><input type="checkbox" id="floater-extract-text" checked> Extract text</label>
            <label><input type="checkbox" id="floater-extract-meta" checked> Extract metadata</label>
            <label><input type="checkbox" id="floater-analyze-struct" checked> Analyze structure</label>
          </div>

          <div class="file-info-section" id="floater-selected-file" style="display:none;">
            <div class="selected-file">
              <span class="file-name"></span>
              <span class="file-size"></span>
              <button class="remove-file">&times;</button>
            </div>
          </div>

          <div class="floater-progress-area" id="floater-upload-progress" style="display:none;">
            <div class="floater-progress-bar"><div class="progress-fill"></div></div>
            <p class="progress-text">Processing...</p>
          </div>
        </div>
        <div class="floater-modal-footer">
          <button class="floater-btn floater-secondary floater-close">Cancel</button>
          <button id="floater-process-pdf" class="floater-btn floater-primary" disabled>Attach PDF</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    const drop = modal.querySelector('#floater-pdf-drop');
    const input = modal.querySelector('#floater-pdf-input');
    const fileBox = modal.querySelector('#floater-selected-file');
    const fileName = fileBox.querySelector('.file-name');
    const fileSize = fileBox.querySelector('.file-size');
    const processBtn = modal.querySelector('#floater-process-pdf');
    let selectedFile = null;

    modal.querySelectorAll('.floater-close').forEach(b => b.addEventListener('click', () => modal.remove()));
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.remove(); });

    const pick = (file) => {
      if (file.type !== 'application/pdf') return this.toast('Select a valid PDF.', true);
      if (file.size > 10 * 1024 * 1024) return this.toast('Max size 10MB.', true);
      selectedFile = file;
      fileName.textContent = file.name;
      fileSize.textContent = this.formatSize(file.size);
      fileBox.style.display = 'block';
      processBtn.disabled = false;
    };

    drop.addEventListener('click', () => input.click());
    drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('drag-over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('drag-over'));
    drop.addEventListener('drop', (e) => {
      e.preventDefault(); drop.classList.remove('drag-over');
      if (e.dataTransfer.files?.length) pick(e.dataTransfer.files[0]);
    });
    input.addEventListener('change', (e) => { if (e.target.files?.length) pick(e.target.files[0]); });

    modal.addEventListener('click', (e) => {
      if (e.target.classList.contains('remove-file')) {
        selectedFile = null; fileBox.style.display = 'none'; processBtn.disabled = true; input.value = '';
      }
    });

    processBtn.addEventListener('click', async () => {
      if (!selectedFile) return;
      await this.processAndAttachPdf(selectedFile, modal);
    });
  }

  async processAndAttachPdf(file, modal) {
    const progressArea = modal.querySelector('#floater-upload-progress');
    const fill = progressArea.querySelector('.progress-fill');
    const txt = progressArea.querySelector('.progress-text');
    const processBtn = modal.querySelector('#floater-process-pdf');

    try {
      if (!this.lastCollected) {
        this.toast('Collect a feedback first, then attach PDF.', true);
        return;
      }

      processBtn.disabled = true;
      progressArea.style.display = 'block';
      txt.textContent = 'Reading PDF...'; fill.style.width = '20%';

      const base64 = await this.fileToBase64(file);

      txt.textContent = 'Processing...'; fill.style.width = '60%';
      const options = {
        extractText: modal.querySelector('#floater-extract-text').checked,
        extractMetadata: modal.querySelector('#floater-extract-meta').checked,
        analyzeStructure: modal.querySelector('#floater-analyze-struct').checked
      };

      const resp = await this.sendToBackground('UPLOAD_PDF', {
        fileData: base64,
        fileName: file.name,
        fileSize: file.size,
        options
      });
      if (!resp?.success) throw new Error(resp?.error || 'PDF processing failed');

      txt.textContent = 'Attaching to feedback...'; fill.style.width = '90%';

      // Attach to lastCollected in memory (and optionally persist a link)
      const pdfInfo = resp.data; // { id, fileName, textLength, hasMetadata, hasStructure }
      const idx = this.collectedData.findIndex(x => x.collectionId === this.lastCollected.collectionId);
      if (idx >= 0) {
        const prev = this.collectedData[idx];
        this.collectedData[idx] = { ...prev, attachments: [...(prev.attachments || []), { type: 'pdf', id: pdfInfo.id, name: pdfInfo.fileName }] };
      }

      fill.style.width = '100%';
      this.toast(`PDF attached to feedback: ${pdfInfo.fileName}`);
      setTimeout(() => modal.remove(), 800);
    } catch (e) {
      this.toast('Attach failed: ' + e.message, true);
    } finally {
      processBtn.disabled = false;
      // keep progressArea visible until modal closes
    }
  }

  // Downloads
  downloadJSON(data) {
    const s = JSON.stringify(data, null, 2);
    this.downloadFile(s, `feedback-data-${Date.now()}.json`, 'application/json');
  }
  downloadCSV(data) {
    if (!data?.length) return;
    const all = [...new Set(data.flatMap(Object.keys))];
    const header = all.join(',');
    const rows = data.map(item => all.map(k => {
      let v = item[k] ?? '';
      if (typeof v === 'object') v = JSON.stringify(v);
      v = String(v).replace(/"/g, '""');
      if (v.includes(',') || v.includes('\n') || v.includes('"')) v = `"${v}"`;
      return v;
    }).join(','));
    this.downloadFile(header + '\n' + rows.join('\n'), `feedback-data-${Date.now()}.csv`, 'text/csv');
  }
  downloadExcel(data) {
    if (!data?.length) return;
    const all = [...new Set(data.flatMap(Object.keys))];
    const header = all.join('\t');
    const rows = data.map(item => all.map(k => {
      let v = item[k] ?? '';
      if (typeof v === 'object') v = JSON.stringify(v);
      return String(v).replace(/\t/g, ' ').replace(/\n/g, ' ');
    }).join('\t'));
    this.downloadFile(header + '\n' + rows.join('\n'), `feedback-data-${Date.now()}.xls`, 'application/vnd.ms-excel');
  }
  downloadFile(content, name, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name; a.style.display = 'none';
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }

  // Helpers
  removeModalById(id) { const m = document.getElementById(id); if (m) m.remove(); }
  toast(message, isError = false) {
    const div = document.createElement('div');
    div.className = 'floater-toast ' + (isError ? 'error' : 'ok');
    div.textContent = message;
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 2500);
  }
  escapeHtml(str) {
    return String(str)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }
  formatSize(bytes) {
    if (!bytes) return '0 Bytes';
    const k = 1024; const sizes = ['Bytes','KB','MB','GB']; const i = Math.floor(Math.log(bytes)/Math.log(k));
    return `${parseFloat((bytes/Math.pow(k,i)).toFixed(2))} ${sizes[i]}`;
  }
  fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.readAsDataURL(file);
      r.onload = () => resolve(r.result);
      r.onerror = (e) => reject(e);
    });
  }
  async sendToBackground(type, data) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type, ...data }, (response) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        resolve(response);
      });
    });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => { window.feedbackExtractor = new FeedbackExtractor(); });
} else {
  window.feedbackExtractor = new FeedbackExtractor();
}
