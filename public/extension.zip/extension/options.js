class OptionsController {
    constructor() {
        this.defaultSettings = {
            analysisServerUrl: '',
            apiEndpoint: '/analyze-extension',
            
            // Collection Settings
            autoCollect: true,
            batchSize: 50,
            collectMetadata: true,
            
            // Export Settings
            exportFormat: 'json',
            includeMetadataInExport: true,
            
            // Data Management
            storageLimit: 100, // MB
            
            // Portal Configuration
            enabledPortals: {
                mygov: true,
                govuk: true,
                citizenspace: true
            }
        };
        this.init();
    }

    async init() {
        console.log('Options page initializing...');
        await this.loadSettings();
        this.setupEventListeners();
        this.updateUI();
        this.updateStorageInfo();
    }

    async loadSettings() {
        try {
            const result = await chrome.storage.local.get(['settings']);
            this.settings = { ...this.defaultSettings, ...result.settings };
            console.log('Settings loaded:', this.settings);
        } catch (error) {
            console.error('Error loading settings:', error);
            this.settings = { ...this.defaultSettings };
        }
    }

    setupEventListeners() {
        // Save button
        const saveBtn = document.getElementById('saveBtn');
        if (saveBtn) saveBtn.addEventListener('click', () => this.saveSettings());

        // Reset button
        const resetBtn = document.getElementById('resetBtn');
        if (resetBtn) resetBtn.addEventListener('click', () => this.resetSettings());

        // Clear data button
        const clearDataBtn = document.getElementById('clearDataBtn');
        if (clearDataBtn) clearDataBtn.addEventListener('click', () => this.clearAllData());

        // Export data button
        const exportDataBtn = document.getElementById('exportDataBtn');
        if (exportDataBtn) exportDataBtn.addEventListener('click', () => this.exportAllData());

        // Test collection button
        const testCollectionBtn = document.getElementById('testCollectionBtn');
        if (testCollectionBtn) testCollectionBtn.addEventListener('click', () => this.testCollection());

        // Test server connection button
        const testServerBtn = document.getElementById('testServerBtn');
        if (testServerBtn) testServerBtn.addEventListener('click', () => this.testServerConnection());

        // Form change listeners
        const formElements = document.querySelectorAll('input, select, textarea');
        formElements.forEach(element => {
            element.addEventListener('change', () => this.onSettingChange(element));
        });

        // Storage refresh button
        const refreshStorageBtn = document.getElementById('refreshStorageBtn');
        if (refreshStorageBtn) refreshStorageBtn.addEventListener('click', () => this.updateStorageInfo());
    }

    updateUI() {
        // Server Configuration
        const analysisServerUrl = document.getElementById('analysisServerUrl');
        if (analysisServerUrl) analysisServerUrl.value = this.settings.analysisServerUrl || '';
        
        const apiEndpoint = document.getElementById('apiEndpoint');
        if (apiEndpoint) apiEndpoint.value = this.settings.apiEndpoint || '/api/analyze';

        // Collection Settings
        const autoCollect = document.getElementById('autoCollect');
        if (autoCollect) autoCollect.checked = this.settings.autoCollect;

        const batchSize = document.getElementById('batchSize');
        if (batchSize) batchSize.value = this.settings.batchSize;

        const collectMetadata = document.getElementById('collectMetadata');
        if (collectMetadata) collectMetadata.checked = this.settings.collectMetadata;

        // Export Settings
        const exportFormat = document.getElementById('exportFormat');
        if (exportFormat) exportFormat.value = this.settings.exportFormat;

        const includeMetadataInExport = document.getElementById('includeMetadataInExport');
        if (includeMetadataInExport) includeMetadataInExport.checked = this.settings.includeMetadataInExport;

        // Data Management
        const storageLimit = document.getElementById('storageLimit');
        if (storageLimit) storageLimit.value = this.settings.storageLimit;

        // Portal Configuration
        if (this.settings.enabledPortals) {
            const mygovPortal = document.getElementById('enableMyGov');
            if (mygovPortal) mygovPortal.checked = this.settings.enabledPortals.mygov;

            const govukPortal = document.getElementById('enableGovUK');
            if (govukPortal) govukPortal.checked = this.settings.enabledPortals.govuk;

            const citizenspacePortal = document.getElementById('enableCitizenSpace');
            if (citizenspacePortal) citizenspacePortal.checked = this.settings.enabledPortals.citizenspace;
        }
    }

    onSettingChange(element) {
        const key = element.id;
        let value;

        if (element.type === 'checkbox') {
            value = element.checked;
        } else if (element.type === 'number') {
            value = parseInt(element.value);
        } else {
            value = element.value;
        }

        // Handle nested portal settings
        if (key.startsWith('enable')) {
            if (!this.settings.enabledPortals) {
                this.settings.enabledPortals = {};
            }
            
            if (key === 'enableMyGov') {
                this.settings.enabledPortals.mygov = value;
            } else if (key === 'enableGovUK') {
                this.settings.enabledPortals.govuk = value;
            } else if (key === 'enableCitizenSpace') {
                this.settings.enabledPortals.citizenspace = value;
            }
        } else {
            this.settings[key] = value;
        }

        console.log(`Setting changed: ${key} = ${value}`);
    }

    async saveSettings() {
        const saveBtn = document.getElementById('saveBtn');
        const originalText = saveBtn ? saveBtn.textContent : '';
        
        try {
            // Show saving state
            if (saveBtn) {
                saveBtn.textContent = 'Saving...';
                saveBtn.disabled = true;
            }

            // Validate settings
            if (!this.validateSettings()) {
                return;
            }

            // Save to storage
            await chrome.storage.local.set({ settings: this.settings });

            // Send update message to background script
            try {
                await chrome.runtime.sendMessage({
                    type: 'UPDATE_SETTINGS',
                    settings: this.settings
                });
            } catch (error) {
                console.warn('Failed to notify background script:', error);
            }

            this.showStatus('Settings saved successfully!', 'success');
        } catch (error) {
            console.error('Error saving settings:', error);
            this.showStatus('Failed to save settings: ' + error.message, 'error');
        } finally {
            // Restore button state
            if (saveBtn) {
                saveBtn.textContent = originalText;
                saveBtn.disabled = false;
            }
        }
    }

    validateSettings() {
        // Validate server URL
        const serverUrl = this.settings.analysisServerUrl;
        if (serverUrl && !this.isValidUrl(serverUrl)) {
            this.showStatus('Please enter a valid server URL (e.g., https://your-website.com)', 'error');
            const serverInput = document.getElementById('analysisServerUrl');
            if (serverInput) serverInput.focus();
            return false;
        }

        // Validate API endpoint
        const apiEndpoint = this.settings.apiEndpoint;
        if (!apiEndpoint || !apiEndpoint.startsWith('/')) {
            this.showStatus('API endpoint must start with / (e.g., /api/analyze)', 'error');
            const endpointInput = document.getElementById('apiEndpoint');
            if (endpointInput) endpointInput.focus();
            return false;
        }

        // Validate batch size
        const batchSize = this.settings.batchSize;
        if (batchSize < 1 || batchSize > 1000) {
            this.showStatus('Batch size must be between 1 and 1000', 'error');
            const batchSizeInput = document.getElementById('batchSize');
            if (batchSizeInput) batchSizeInput.focus();
            return false;
        }

        // Validate storage limit
        const storageLimit = this.settings.storageLimit;
        if (storageLimit < 10 || storageLimit > 1000) {
            this.showStatus('Storage limit must be between 10 and 1000 MB', 'error');
            const storageLimitInput = document.getElementById('storageLimit');
            if (storageLimitInput) storageLimitInput.focus();
            return false;
        }

        return true;
    }

    isValidUrl(string) {
        try {
            const url = new URL(string);
            return url.protocol === 'http:' || url.protocol === 'https:';
        } catch (_) {
            return false;
        }
    }

    async resetSettings() {
        if (!confirm('Are you sure you want to reset all settings to defaults?')) {
            return;
        }

        try {
            this.settings = { ...this.defaultSettings };
            this.updateUI();
            await this.saveSettings();
            this.showStatus('Settings reset to defaults', 'success');
        } catch (error) {
            console.error('Error resetting settings:', error);
            this.showStatus('Failed to reset settings: ' + error.message, 'error');
        }
    }

    async testServerConnection() {
        const testBtn = document.getElementById('testServerBtn');
        const originalText = testBtn ? testBtn.textContent : '';
        
        try {
            if (testBtn) {
                testBtn.textContent = 'Testing...';
                testBtn.disabled = true;
            }

            const serverUrl = this.settings.analysisServerUrl;
            const endpoint = this.settings.apiEndpoint;

            if (!serverUrl) {
                throw new Error('Server URL not configured');
            }

            const url = serverUrl.replace(/\/$/, '') + endpoint;
            
            // Send test payload
            const testPayload = {
                timestamp: new Date().toISOString(),
                source: 'regulation_feedback_extension',
                version: '1.0.0',
                test: true,
                count: 1,
                data: [{
                    id: 'test_' + Date.now(),
                    text: 'This is a test message to verify server connectivity',
                    author: 'Test User',
                    portal: 'Test Portal',
                    url: 'https://example.com/test',
                    timestamp: new Date().toISOString(),
                    metadata: {
                        title: 'Test Connection',
                        test: true
                    }
                }]
            };

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Extension-Version': '1.0.0',
                    'X-Data-Source': 'regulation-feedback-collector',
                    'X-Test-Connection': 'true'
                },
                body: JSON.stringify(testPayload)
            });

            if (response.ok) {
                const result = await response.json().catch(() => ({ status: 'ok' }));
                this.showStatus(`Server connection successful! Response: ${response.status}`, 'success');
                console.log('Server test response:', result);
            } else {
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

        } catch (error) {
            console.error('Server test error:', error);
            this.showStatus('Server connection failed: ' + error.message, 'error');
        } finally {
            if (testBtn) {
                testBtn.textContent = originalText;
                testBtn.disabled = false;
            }
        }
    }

    async clearAllData() {
        const message = 'This will permanently delete all collected feedback data and statistics. This action cannot be undone.\n\nAre you sure you want to continue?';
        if (!confirm(message)) {
            return;
        }

        const clearBtn = document.getElementById('clearDataBtn');
        const originalText = clearBtn ? clearBtn.textContent : '';
        
        try {
            if (clearBtn) {
                clearBtn.textContent = 'Clearing...';
                clearBtn.disabled = true;
            }

            // Get all storage keys
            const allData = await chrome.storage.local.get(null);
            const keysToRemove = [];

            // Identify data keys (keep settings)
            Object.keys(allData).forEach(key => {
                if (key.startsWith('feedback-') ||
                    key.startsWith('pdf-') ||
                    key === 'stats' ||
                    key === 'syncQueue' ||
                    key === 'lastSync' ||
                    key === 'collectedData') {
                    keysToRemove.push(key);
                }
            });

            // Remove data
            if (keysToRemove.length > 0) {
                await chrome.storage.local.remove(keysToRemove);
            }

            // Reset stats
            const resetStats = { collected: 0, pending: 0, synced: 0 };
            await chrome.storage.local.set({ stats: resetStats });

            // Notify background script
            try {
                await chrome.runtime.sendMessage({
                    type: 'DATA_CLEARED'
                });
            } catch (error) {
                console.warn('Failed to notify background script:', error);
            }

            this.showStatus(`Cleared ${keysToRemove.length} data items and reset statistics`, 'success');
            this.updateStorageInfo();
        } catch (error) {
            console.error('Error clearing data:', error);
            this.showStatus('Failed to clear data: ' + error.message, 'error');
        } finally {
            if (clearBtn) {
                clearBtn.textContent = originalText;
                clearBtn.disabled = false;
            }
        }
    }

    async exportAllData() {
        try {
            const exportBtn = document.getElementById('exportDataBtn');
            if (exportBtn) {
                exportBtn.textContent = 'Exporting...';
                exportBtn.disabled = true;
            }

            const result = await chrome.runtime.sendMessage({ type: 'GET_COLLECTED_DATA' });
            const data = result?.data || [];

            if (data.length === 0) {
                this.showStatus('No data available to export', 'error');
                return;
            }

            const format = this.settings.exportFormat;
            let content, filename, mimeType;

            if (format === 'csv') {
                content = this.convertToCSV(data);
                filename = `feedback-export-${new Date().toISOString().split('T')[0]}.csv`;
                mimeType = 'text/csv';
            } else {
                content = JSON.stringify(data, null, 2);
                filename = `feedback-export-${new Date().toISOString().split('T')[0]}.json`;
                mimeType = 'application/json';
            }

            this.downloadFile(content, filename, mimeType);
            this.showStatus(`Exported ${data.length} items as ${format.toUpperCase()}`, 'success');

        } catch (error) {
            console.error('Export error:', error);
            this.showStatus('Failed to export data: ' + error.message, 'error');
        } finally {
            const exportBtn = document.getElementById('exportDataBtn');
            if (exportBtn) {
                exportBtn.textContent = 'Export All Data';
                exportBtn.disabled = false;
            }
        }
    }

    async testCollection() {
        try {
            const testBtn = document.getElementById('testCollectionBtn');
            if (testBtn) {
                testBtn.textContent = 'Testing...';
                testBtn.disabled = true;
            }

            const result = await chrome.runtime.sendMessage({ type: 'TEST_COLLECTION' });
            
            if (result?.success) {
                this.showStatus('Collection test completed successfully', 'success');
                console.log('Test collection result:', result);
            } else {
                this.showStatus('Collection test failed: ' + (result?.error || 'Unknown error'), 'error');
            }

        } catch (error) {
            console.error('Test error:', error);
            this.showStatus('Test failed: ' + error.message, 'error');
        } finally {
            const testBtn = document.getElementById('testCollectionBtn');
            if (testBtn) {
                testBtn.textContent = 'Test Collection';
                testBtn.disabled = false;
            }
        }
    }

    convertToCSV(data) {
        if (!data.length) return '';
        const headers = ['Text', 'Author', 'Portal', 'URL', 'Timestamp'];
        const includeMetadata = this.settings.includeMetadataInExport;
        
        if (includeMetadata) {
            headers.push('Metadata');
        }
        
        const rows = data.map(item => {
            const row = [
                (item.text || '').replace(/"/g, '""'),
                (item.author || '').replace(/"/g, '""'),
                (item.portalType || item.portalName || '').replace(/"/g, '""'),
                (item.sourceUrl || item.url || '').replace(/"/g, '""'),
                item.timestamp ? new Date(item.timestamp).toISOString() : ''
            ];
            
            if (includeMetadata) {
                const metadata = {
                    title: item.sourceTitle || item.title || '',
                    votes: item.votes || 0,
                    collectionId: item.collectionId || item.id || '',
                    stableId: item.stableId || ''
                };
                row.push(JSON.stringify(metadata).replace(/"/g, '""'));
            }
            
            return row;
        });
        
        return [headers, ...rows]
            .map(row => row.map(cell => `"${cell}"`).join(','))
            .join('\n');
    }

    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    async updateStorageInfo() {
        try {
            const usageMB = await this.getStorageUsage();
            const statsResult = await chrome.runtime.sendMessage({ type: 'GET_STATS' });
            const stats = statsResult?.data || { collected: 0, pending: 0, synced: 0 };
            
            // Get last sync info
            const syncInfo = await chrome.storage.local.get(['lastSync']);
            const lastSync = syncInfo.lastSync;
            
            const storageInfo = document.getElementById('storageInfo');
            if (storageInfo) {
                storageInfo.innerHTML = `
                    <div class="storage-stats">
                        <div class="stat-item">
                            <span class="stat-label">Storage Used</span>
                            <span class="stat-value">${usageMB} MB</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Items Collected</span>
                            <span class="stat-value">${stats.collected}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Items Pending</span>
                            <span class="stat-value">${stats.pending}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Items Synced</span>
                            <span class="stat-value">${stats.synced}</span>
                        </div>
                    </div>
                    ${lastSync ? `
                    <div class="sync-info">
                        <strong>Last Sync:</strong> ${new Date(lastSync.timestamp).toLocaleString()}<br>
                        <strong>Status:</strong> <span class="sync-${lastSync.status}">${lastSync.status}</span><br>
                        <strong>Items:</strong> ${lastSync.count}<br>
                        ${lastSync.error ? `<strong>Error:</strong> ${lastSync.error}<br>` : ''}
                        <strong>Server:</strong> ${lastSync.server}
                    </div>
                    ` : ''}
                `;
            }
        } catch (error) {
            console.error('Error updating storage info:', error);
        }
    }

    async getStorageUsage() {
        try {
            const usage = await chrome.storage.local.getBytesInUse();
            const usageMB = (usage / (1024 * 1024)).toFixed(2);
            return usageMB;
        } catch (error) {
            console.error('Error getting storage usage:', error);
            return '0.00';
        }
    }

    showStatus(message, type = 'success') {
        const statusMessage = document.getElementById('statusMessage');
        if (statusMessage) {
            statusMessage.textContent = message;
            statusMessage.className = `status-message status-${type}`;
            statusMessage.style.display = 'block';

            // Auto-hide after 5 seconds
            setTimeout(() => {
                statusMessage.style.display = 'none';
            }, 5000);

            // Scroll to top to ensure message is visible
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new OptionsController();
});

// Handle keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl+S or Cmd+S to save
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        const saveBtn = document.getElementById('saveBtn');
        if (saveBtn) saveBtn.click();
    }

    // Ctrl+Shift+R or Cmd+Shift+R to reset (with confirmation)
    if ((e.ctrlKey || e.metaKey) && e.key === 'R' && e.shiftKey) {
        e.preventDefault();
        const resetBtn = document.getElementById('resetBtn');
        if (resetBtn) resetBtn.click();
    }

    // Ctrl+E or Cmd+E to export
    if ((e.ctrlKey || e.metaKey) && e.key === 'e') {
        e.preventDefault();
        const exportBtn = document.getElementById('exportDataBtn');
        if (exportBtn) exportBtn.click();
    }
});
