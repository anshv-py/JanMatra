// Popup Script for Regulation Feedback Collector Extension (No Auth Version)
class PopupController {
    constructor() {
        this.currentTab = null;
        this.stats = { collected: 0, pending: 0, synced: 0 };
        this.collectedData = [];
        this.selectedFile = null;
        this.init();
    }

    async init() {
        await this.wakeServiceWorker();
        await this.getCurrentTab();
        this.setupEventListeners();
        this.updateCurrentPageInfo();
        await this.loadStats();
        this.setupPeriodicUpdates();
    }

    async getCurrentTab() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            this.currentTab = tab || null;
        } catch (e) {
            console.error('getCurrentTab error', e);
        }
    }

    setupEventListeners() {
        const previewDataBtn = document.getElementById('previewDataBtn');
        if (previewDataBtn) previewDataBtn.addEventListener('click', () => this.showPreviewModal());
        
        const sendToServerBtn = document.getElementById('sendToServerBtn');
        if (sendToServerBtn) sendToServerBtn.addEventListener('click', () => this.sendToServer());
        
        const startCollectionBtn = document.getElementById('startCollectionBtn');
        if (startCollectionBtn) startCollectionBtn.addEventListener('click', () => this.startCollection());
        
        const exportDataBtn = document.getElementById('exportDataBtn');
        if (exportDataBtn) exportDataBtn.addEventListener('click', () => this.showExportModal());
        
        const uploadPdfBtn = document.getElementById('uploadPdfBtn');
        if (uploadPdfBtn) uploadPdfBtn.addEventListener('click', () => this.showPdfUploadModal());
        
        const settingsBtn = document.getElementById('settingsBtn');
        if (settingsBtn) settingsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());
        
        const clearDataBtn = document.getElementById('clearDataBtn');
        if (clearDataBtn) clearDataBtn.addEventListener('click', () => this.clearAllData());
    }

    updateCurrentPageInfo() {
        if (!this.currentTab) return;
        const pageTitle = document.getElementById('pageTitle');
        const pageUrl = document.getElementById('pageUrl');
        
        if (pageTitle) pageTitle.textContent = this.currentTab.title || 'Unknown Page';
        if (pageUrl) {
            try {
                pageUrl.textContent = new URL(this.currentTab.url).hostname;
            } catch {
                pageUrl.textContent = 'Unknown host';
            }
        }
        this.checkPortalSupport();
    }

    async checkPortalSupport() {
        const portalStatus = document.getElementById('portalStatus');
        try {
            const res = await this.sendMessageToBackground('GET_PORTAL_CONFIG', { url: this.currentTab?.url });
            const cfg = res?.data ?? res;
            
            if (cfg && cfg.name) {
                portalStatus.innerHTML = `<span class="portal-name">✓ Supported: ${cfg.name}</span>`;
            } else {
                portalStatus.innerHTML = `<span class="portal-name">⚪ Generic Portal</span>`;
            }
        } catch (e) {
            if (portalStatus) {
                portalStatus.innerHTML = `<span class="portal-name">❓ Unknown Portal</span>`;
            }
        }
    }

    async loadStats() {
        try {
            const res = await this.sendMessageToBackground('GET_STATS');
            if (res?.success) {
                this.stats = res.data;
            }
            
            // Also get collected data count directly
            const dataRes = await this.sendMessageToBackground('GET_COLLECTED_DATA');
            if (dataRes?.data) {
                this.stats.collected = dataRes.data.length;
            }
            
            this.updateStatsDisplay();
        } catch (e) {
            if (String(e.message).includes('Receiving end does not exist')) {
                try {
                    await this.wakeServiceWorker();
                    const res2 = await this.sendMessageToBackground('GET_STATS');
                    if (res2?.success) this.stats = res2.data;
                    
                    const dataRes2 = await this.sendMessageToBackground('GET_COLLECTED_DATA');
                    if (dataRes2?.data) {
                        this.stats.collected = dataRes2.data.length;
                    }
                    
                    this.updateStatsDisplay();
                    return;
                } catch (_) {}
            }
            console.error('loadStats error', e);
        }
    }

    updateStatsDisplay() {
        const collectedCount = document.getElementById('collectedCount');
        const pendingCount = document.getElementById('pendingCount');
        const syncedCount = document.getElementById('syncedCount');
        
        if (collectedCount) collectedCount.textContent = this.stats.collected || 0;
        if (pendingCount) pendingCount.textContent = this.stats.pending || 0;
        if (syncedCount) syncedCount.textContent = this.stats.synced || 0;
    }

    async showPreviewModal() {
        try {
            const res = await this.sendMessageToBackground('GET_COLLECTED_DATA');
            const data = res?.data || [];
            if (!data.length) return this.showError('No data available. Collect first.');

            const unique = [];
            const seen = new Set();
            for (const it of data) {
                const key = (it.stableId || '') + '|' + (it.text || '').trim().slice(0, 160).toLowerCase();
                if (seen.has(key)) continue;
                seen.add(key);
                unique.push(it);
            }
            this.createPreviewModal(unique);
        } catch (e) {
            this.showError('Failed to load preview: ' + e.message);
        }
    }

    createPreviewModal(items) {
        this.removeExistingModal('preview-modal');
        const htmlRows = items.slice(0, 20).map((it, idx) => `
            <div class="preview-row">
                <span class="preview-idx">${idx + 1}</span>
                <span class="preview-text">${this.escapeHtml((it.text || '').slice(0, 200))}</span>
                <span class="preview-meta">
                    Portal: ${this.escapeHtml(it.portalName || 'Unknown')}<br>
                    Time: ${it.timestamp ? new Date(it.timestamp).toLocaleString() : 'Unknown'}
                </span>
            </div>
        `).join('');

        const modal = this.createModal('preview-modal', 'Data Preview', `
            <div class="preview-list">
                ${htmlRows}
                ${items.length > 20 ? `<div class="preview-more">... and ${items.length - 20} more items</div>` : ''}
            </div>
        `, [
            { text: 'Close', class: 'floater-secondary', onclick: `window.popupController.removeExistingModal('preview-modal')` }
        ]);
        
        document.body.appendChild(modal);
    }

    async showExportModal() {
        try {
            const res = await this.sendMessageToBackground('GET_COLLECTED_DATA');
            const data = res?.data || [];
            if (!data.length) return this.showError('No data to export. Collect first.');

            this.removeExistingModal('export-modal');
            const modal = this.createModal('export-modal', 'Export Data', `
                <div class="export-options">
                    <p>Export ${data.length} collected items</p>
                    <div class="export-formats">
                        <button class="control-btn primary" onclick="window.popupController.exportAsJSON()">Export as JSON</button>
                        <button class="control-btn secondary" onclick="window.popupController.exportAsCSV()">Export as CSV</button>
                    </div>
                </div>
            `, [
                { text: 'Close', class: 'floater-secondary', onclick: `window.popupController.removeExistingModal('export-modal')` }
            ]);
            
            document.body.appendChild(modal);
        } catch (e) {
            this.showError('Failed to load export data: ' + e.message);
        }
    }

    async showPdfUploadModal() {
        this.removeExistingModal('pdf-upload-modal');
        const modal = this.createModal('pdf-upload-modal', 'Upload PDF', `
            <div class="file-drop-zone" id="pdfDropZone">
                <div class="drop-zone-content">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
                    </svg>
                    <p>Drop PDF file here or click to browse</p>
                    <div class="file-info">PDF up to 10MB</div>
                </div>
            </div>
            <input type="file" id="pdfFileInput" accept=".pdf" style="display: none;">
            <div id="selectedFileInfo" class="file-info-section" style="display: none;"></div>
        `, [
            { text: 'Upload', class: 'floater-primary', onclick: `window.popupController.uploadPdfFile()` },
            { text: 'Cancel', class: 'floater-secondary', onclick: `window.popupController.removeExistingModal('pdf-upload-modal')` }
        ]);

        this.setupPdfUploadHandlers(modal);
        document.body.appendChild(modal);
    }

    setupPdfUploadHandlers(modal) {
        const dropZone = modal.querySelector('#pdfDropZone');
        const fileInput = modal.querySelector('#pdfFileInput');
        const fileInfo = modal.querySelector('#selectedFileInfo');

        if (dropZone) {
            dropZone.addEventListener('click', () => {
                if (fileInput) fileInput.click();
            });
            
            dropZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                dropZone.classList.add('drag-over');
            });

            dropZone.addEventListener('dragleave', () => {
                dropZone.classList.remove('drag-over');
            });

            dropZone.addEventListener('drop', (e) => {
                e.preventDefault();
                dropZone.classList.remove('drag-over');
                const files = e.dataTransfer.files;
                if (files.length > 0) this.handleFileSelect(files[0], fileInfo);
            });
        }

        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                if (e.target.files.length > 0) this.handleFileSelect(e.target.files[0], fileInfo);
            });
        }
    }

    handleFileSelect(file, fileInfoElement) {
        if (file.type !== 'application/pdf') {
            this.showError('Please select a PDF file');
            return;
        }

        if (file.size > 10 * 1024 * 1024) {
            this.showError('File size must be less than 10MB');
            return;
        }

        this.selectedFile = file;
        if (fileInfoElement) {
            fileInfoElement.innerHTML = `
                <div class="selected-file">
                    <span class="file-name">${file.name}</span>
                    <span class="file-size">${(file.size / 1024 / 1024).toFixed(2)} MB</span>
                    <button class="remove-file" onclick="window.popupController.clearSelectedFile()">×</button>
                </div>
            `;
            fileInfoElement.style.display = 'block';
        }
    }

    clearSelectedFile() {
        this.selectedFile = null;
        const fileInfo = document.querySelector('#selectedFileInfo');
        if (fileInfo) {
            fileInfo.style.display = 'none';
            fileInfo.innerHTML = '';
        }
    }

    async uploadPdfFile() {
        if (!this.selectedFile) {
            this.showError('Please select a PDF file first');
            return;
        }

        try {
            this.showStatus('Uploading PDF...', 'info');
            const fileData = await this.fileToBase64(this.selectedFile);
            const uploadRes = await this.sendMessageToBackground('UPLOAD_PDF', {
                fileName: this.selectedFile.name,
                fileData: fileData,
                fileSize: this.selectedFile.size
            });
            
            if (uploadRes?.success) {
                this.showStatus('PDF uploaded successfully', 'success');
                this.removeExistingModal('pdf-upload-modal');
                this.clearSelectedFile();
                await this.loadStats();
            } else {
                throw new Error(uploadRes?.error || 'Upload failed');
            }
        } catch (e) {
            this.showError('Failed to upload PDF: ' + e.message);
        }
    }

    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result.split(',')[1]);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    async sendToServer() {
        try {
            const res = await this.sendMessageToBackground('GET_COLLECTED_DATA');
            const data = res?.data || [];
            if (!data.length) return this.showError('No data to send. Collect first.');

            this.showSendModal(data.length);
            const sendRes = await this.sendMessageToBackground('SEND_TO_SERVER', { data });
            
            if (sendRes?.success) {
                this.showStatus('Data sent successfully!', 'success');
                await this.loadStats();
            } else {
                throw new Error(sendRes?.error || 'Send failed');
            }
        } catch (e) {
            this.showError('Failed to send data: ' + e.message);
        } finally {
            this.removeExistingModal('send-modal');
        }
    }

    showSendModal(count) {
        this.removeExistingModal('send-modal');
        const modal = this.createModal('send-modal', 'Sending Data', `
            <div class="send-progress">
                <p>Sending ${count} items to sentiment analysis server...</p>
                <div class="floater-progress-bar">
                    <div class="progress-fill" style="width: 0%; animation: progress 3s ease-in-out infinite;"></div>
                </div>
                <div class="progress-status">Preparing request...</div>
            </div>
            <style>
                @keyframes progress {
                    0% { width: 0%; }
                    50% { width: 70%; }
                    100% { width: 100%; }
                }
            </style>
        `, []);
        
        document.body.appendChild(modal);
    }

    async startCollection() {
        try {
            const startBtn = document.getElementById('startCollectionBtn');
            if (startBtn) {
                startBtn.textContent = 'Starting...';
                startBtn.disabled = true;
            }

            await this.sendMessageToBackground('START_COLLECTION');
            this.showStatus('Collection started on current page', 'success');
            
            // Update stats after a delay to allow collection to begin
            setTimeout(async () => {
                await this.loadStats();
                if (startBtn) {
                    startBtn.textContent = 'Start Collection';
                    startBtn.disabled = false;
                }
            }, 2000);
        } catch (e) {
            this.showError('Failed to start collection: ' + e.message);
            const startBtn = document.getElementById('startCollectionBtn');
            if (startBtn) {
                startBtn.textContent = 'Start Collection';
                startBtn.disabled = false;
            }
        }
    }

    async clearAllData() {
        if (!confirm('Clear all collected data? This cannot be undone.')) return;
        
        try {
            await this.sendMessageToBackground('CLEAR_ALL_DATA');
            this.stats = { collected: 0, pending: 0, synced: 0 };
            this.updateStatsDisplay();
            this.showStatus('All data cleared', 'success');
        } catch (e) {
            this.showError('Failed to clear data: ' + e.message);
        }
    }

    async exportAsJSON() {
        try {
            const res = await this.sendMessageToBackground('GET_COLLECTED_DATA');
            const data = res?.data || [];
            this.downloadFile(JSON.stringify(data, null, 2), 'feedback-data.json', 'application/json');
            this.removeExistingModal('export-modal');
            this.showStatus('JSON export completed', 'success');
        } catch (e) {
            this.showError('Export failed: ' + e.message);
        }
    }

    async exportAsCSV() {
        try {
            const res = await this.sendMessageToBackground('GET_COLLECTED_DATA');
            const data = res?.data || [];
            const csv = this.convertToCSV(data);
            this.downloadFile(csv, 'feedback-data.csv', 'text/csv');
            this.removeExistingModal('export-modal');
            this.showStatus('CSV export completed', 'success');
        } catch (e) {
            this.showError('Export failed: ' + e.message);
        }
    }

    convertToCSV(data) {
        if (!data.length) return '';
        const headers = ['Text', 'Author', 'Portal', 'URL', 'Timestamp'];
        const rows = data.map(item => [
            (item.text || '').replace(/"/g, '""'),
            (item.author || '').replace(/"/g, '""'),
            (item.portalName || '').replace(/"/g, '""'),
            (item.url || '').replace(/"/g, '""'),
            item.timestamp ? new Date(item.timestamp).toISOString() : ''
        ]);
        
        return [headers, ...rows]
            .map(row => row.map(cell => `"${cell}"`).join(','))
            .join('\n');
    }

    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    createModal(id, title, body, buttons) {
        const modal = document.createElement('div');
        modal.id = id;
        modal.className = 'floater-modal-overlay';
        
        modal.innerHTML = `
            <div class="floater-modal">
                <div class="floater-modal-header">
                    <h3>${title}</h3>
                    <button class="floater-close" onclick="window.popupController.removeExistingModal('${id}')">&times;</button>
                </div>
                <div class="floater-modal-body">${body}</div>
                ${buttons.length > 0 ? `
                <div class="floater-modal-footer">
                    ${buttons.map(btn => `
                        <button class="floater-btn ${btn.class}" onclick="${btn.onclick}">${btn.text}</button>
                    `).join('')}
                </div>` : ''}
            </div>
        `;
        
        // Close modal when clicking overlay
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.removeExistingModal(id);
            }
        });
        
        return modal;
    }

    removeExistingModal(id) {
        const existing = document.getElementById(id);
        if (existing) existing.remove();
    }

    setupPeriodicUpdates() {
        setInterval(() => this.loadStats(), 5000);
    }

    async wakeServiceWorker() {
        try {
            await chrome.runtime.sendMessage({ type: 'PING' });
        } catch (e) {
            console.log('Service worker wake attempt:', e.message);
        }
    }

    async sendMessageToBackground(type, data = {}) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ type, ...data }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
    }

    showError(message) {
        this.showToast(message, 'error');
    }

    showStatus(message, type = 'ok') {
        this.showToast(message, type);
    }

    showToast(message, type) {
        // Remove existing toasts
        const existingToasts = document.querySelectorAll('.floater-toast');
        existingToasts.forEach(toast => toast.remove());

        const toast = document.createElement('div');
        toast.className = `floater-toast ${type}`;
        toast.textContent = message;
        
        // Add close button to toast
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '×';
        closeBtn.className = 'toast-close';
        closeBtn.onclick = () => toast.remove();
        toast.appendChild(closeBtn);
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentNode) toast.remove();
        }, 4000);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    setLoadingState(button, isLoading) {
        if (isLoading) {
            button.disabled = true;
            button.dataset.originalText = button.textContent;
            button.textContent = 'Loading...';
        } else {
            button.disabled = false;
            button.textContent = button.dataset.originalText || 'Submit';
        }
    }
}

// Initialize popup controller
window.popupController = new PopupController();
