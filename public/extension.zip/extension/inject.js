// Injectable Script for Regulation Feedback Collector
// This script runs in the page context for advanced DOM access

(function() {
    'use strict';

    // Create namespace
    window.FeedbackCollectorInject = window.FeedbackCollectorInject || {};

    const FeedbackCollectorInject = {
        // Configuration
        config: {
            maxRetries: 3,
            retryDelay: 1000,
            observerTimeout: 30000
        },

        // State
        isActive: false,
        observers: [],
        extractedData: new Set(),

        // Initialize the injected collector
        init: function() {
            console.log('[FeedbackCollector] Injected script initialized');
            this.isActive = true;

            // Set up advanced extraction methods
            this.setupAdvancedExtraction();

            // Listen for messages from content script
            window.addEventListener('message', this.handleMessage.bind(this));

            // Notify content script that inject is ready
            this.postMessage('INJECT_READY', { timestamp: Date.now() });
        },

        // Handle messages from content script
        handleMessage: function(event) {
            if (event.source !== window) return;
            if (!event.data.type || !event.data.type.startsWith('FEEDBACK_COLLECTOR_')) return;

            const { type, payload } = event.data;

            switch (type) {
                case 'FEEDBACK_COLLECTOR_START_ADVANCED_EXTRACTION':
                    this.startAdvancedExtraction(payload);
                    break;
                case 'FEEDBACK_COLLECTOR_STOP_EXTRACTION':
                    this.stopExtraction();
                    break;
                case 'FEEDBACK_COLLECTOR_GET_PAGE_DATA':
                    this.getPageData(payload);
                    break;
                case 'FEEDBACK_COLLECTOR_EXTRACT_FORMS':
                    this.extractForms(payload);
                    break;
                default:
                    console.warn('[FeedbackCollector] Unknown message type:', type);
            }
        },

        // Post message to content script
        postMessage: function(type, data) {
            window.postMessage({
                type: `FEEDBACK_COLLECTOR_${type}`,
                payload: data,
                timestamp: Date.now()
            }, '*');
        },

        // Set up advanced extraction methods
        setupAdvancedExtraction: function() {
            // Override form submit to capture data
            this.interceptFormSubmissions();

            // Set up AJAX interception
            this.interceptAjaxRequests();

            // Monitor for dynamic content
            this.setupDynamicContentMonitoring();
        },

        // Intercept form submissions
        interceptFormSubmissions: function() {
            const originalSubmit = HTMLFormElement.prototype.submit;
            const self = this;

            HTMLFormElement.prototype.submit = function() {
                if (self.isActive) {
                    const formData = self.extractFormData(this);
                    if (formData && self.isRelevantForm(this)) {
                        self.postMessage('FORM_SUBMITTED', {
                            url: window.location.href,
                            form: formData,
                            timestamp: Date.now()
                        });
                    }
                }
                return originalSubmit.call(this);
            };

            // Also handle submit events
            document.addEventListener('submit', function(event) {
                if (self.isActive && self.isRelevantForm(event.target)) {
                    const formData = self.extractFormData(event.target);
                    if (formData) {
                        self.postMessage('FORM_SUBMITTED', {
                            url: window.location.href,
                            form: formData,
                            timestamp: Date.now()
                        });
                    }
                }
            });
        },

        // Intercept AJAX requests for dynamic content
        interceptAjaxRequests: function() {
            const self = this;
            const originalXHR = window.XMLHttpRequest;
            const originalFetch = window.fetch;

            // Intercept XMLHttpRequest
            window.XMLHttpRequest = function() {
                const xhr = new originalXHR();
                const originalOpen = xhr.open;
                const originalSend = xhr.send;

                xhr.open = function(method, url) {
                    this._method = method;
                    this._url = url;
                    return originalOpen.apply(this, arguments);
                };

                xhr.send = function(data) {
                    if (self.isActive && self.isRelevantRequest(this._url)) {
                        this.addEventListener('load', function() {
                            if (this.status >= 200 && this.status < 300) {
                                try {
                                    const responseData = JSON.parse(this.responseText);
                                    if (self.containsFeedbackData(responseData)) {
                                        self.postMessage('AJAX_FEEDBACK_DETECTED', {
                                            url: this._url,
                                            method: this._method,
                                            response: responseData,
                                            timestamp: Date.now()
                                        });
                                    }
                                } catch (e) {
                                    // Not JSON or parsing failed
                                }
                            }
                        });
                    }
                    return originalSend.apply(this, arguments);
                };

                return xhr;
            };

            // Intercept fetch requests
            window.fetch = function(url, options) {
                const promise = originalFetch.apply(this, arguments);

                if (self.isActive && self.isRelevantRequest(url)) {
                    promise.then(response => {
                        if (response.ok) {
                            response.clone().json().then(data => {
                                if (self.containsFeedbackData(data)) {
                                    self.postMessage('FETCH_FEEDBACK_DETECTED', {
                                        url: typeof url === 'string' ? url : url.url,
                                        response: data,
                                        timestamp: Date.now()
                                    });
                                }
                            }).catch(() => {
                                // Not JSON or parsing failed
                            });
                        }
                    }).catch(() => {
                        // Request failed
                    });
                }

                return promise;
            };
        },

        // Monitor for dynamic content changes
        setupDynamicContentMonitoring: function() {
            const self = this;

            // Create mutation observer for new feedback content
            const observer = new MutationObserver(function(mutations) {
                if (!self.isActive) return;

                mutations.forEach(function(mutation) {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            // Check if added node contains feedback elements
                            const feedbackElements = self.findFeedbackElements(node);
                            if (feedbackElements.length > 0) {
                                self.postMessage('DYNAMIC_FEEDBACK_DETECTED', {
                                    elements: feedbackElements.map(el => self.serializeElement(el)),
                                    timestamp: Date.now()
                                });
                            }
                        }
                    });
                });
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            this.observers.push(observer);

            // Clean up after timeout
            setTimeout(() => {
                if (this.observers.includes(observer)) {
                    observer.disconnect();
                    this.observers = this.observers.filter(obs => obs !== observer);
                }
            }, this.config.observerTimeout);
        },

        // Extract comprehensive page data
        getPageData: function(config) {
            const pageData = {
                url: window.location.href,
                title: document.title,
                timestamp: Date.now(),
                metadata: this.getPageMetadata(),
                forms: this.getAllForms(),
                comments: this.getAllComments(config),
                scripts: this.getPageScripts(),
                dynamicContent: this.checkForDynamicContent()
            };

            this.postMessage('PAGE_DATA_EXTRACTED', pageData);
        },

        // Get page metadata
        getPageMetadata: function() {
            const metadata = {};

            // Meta tags
            const metaTags = document.querySelectorAll('meta');
            metaTags.forEach(tag => {
                const name = tag.getAttribute('name') || tag.getAttribute('property');
                const content = tag.getAttribute('content');
                if (name && content) {
                    metadata[name] = content;
                }
            });

            // Structured data
            const structuredData = [];
            document.querySelectorAll('script[type="application/ld+json"]').forEach(script => {
                try {
                    structuredData.push(JSON.parse(script.textContent));
                } catch (e) {
                    // Invalid JSON
                }
            });

            metadata.structuredData = structuredData;

            return metadata;
        },

        // Extract all forms on the page
        getAllForms: function() {
            const forms = [];
            document.querySelectorAll('form').forEach(form => {
                if (this.isRelevantForm(form)) {
                    forms.push(this.extractFormData(form));
                }
            });
            return forms;
        },

        // Extract all comments/feedback
        getAllComments: function(config) {
            const comments = [];
            const selectors = config?.selectors || {};

            // Use provided selectors or common patterns
            const commentSelectors = [
                selectors.comments,
                '.comment', '.feedback', '.response', '.review',
                '[data-comment]', '[data-feedback]', '[data-response]',
                '.consultation-response', '.public-comment'
            ].filter(Boolean);

            commentSelectors.forEach(selector => {
                try {
                    document.querySelectorAll(selector).forEach(element => {
                        const commentData = this.extractCommentData(element, selectors);
                        if (commentData && !this.isDuplicateComment(commentData)) {
                            comments.push(commentData);
                        }
                    });
                } catch (e) {
                    console.warn('Invalid selector:', selector);
                }
            });

            return comments;
        },

        // Extract comment data from element
        extractCommentData: function(element, selectors = {}) {
            try {
                const textElement = element.querySelector(selectors.commentText) || element;
                const text = this.getCleanText(textElement);

                if (!text || text.length < 10) return null; // Skip very short text

                return {
                    id: this.generateElementId(element),
                    text: text,
                    author: this.getCommentAuthor(element, selectors),
                    timestamp: this.getCommentTimestamp(element, selectors),
                    votes: this.getCommentVotes(element, selectors),
                    metadata: {
                        xpath: this.getXPath(element),
                        cssSelector: this.getCSSSelector(element),
                        position: this.getElementPosition(element)
                    }
                };
            } catch (e) {
                console.error('Error extracting comment data:', e);
                return null;
            }
        },

        // Get comment author
        getCommentAuthor: function(element, selectors) {
            const authorSelectors = [
                selectors.author,
                '.author', '.user', '.name', '.commenter',
                '[data-author]', '[data-user]'
            ].filter(Boolean);

            for (const selector of authorSelectors) {
                const authorElement = element.querySelector(selector);
                if (authorElement) {
                    return this.getCleanText(authorElement);
                }
            }

            return 'Anonymous';
        },

        // Get comment timestamp
        getCommentTimestamp: function(element, selectors) {
            const timestampSelectors = [
                selectors.timestamp,
                '.date', '.time', '.timestamp', '.posted-date',
                '[data-timestamp]', '[data-date]', 'time'
            ].filter(Boolean);

            for (const selector of timestampSelectors) {
                const timeElement = element.querySelector(selector);
                if (timeElement) {
                    const timeText = this.getCleanText(timeElement);
                    const datetime = timeElement.getAttribute('datetime');
                    return datetime || timeText;
                }
            }

            return null;
        },

        // Get comment votes/ratings
        getCommentVotes: function(element, selectors) {
            const voteSelectors = [
                selectors.votes,
                '.votes', '.score', '.rating', '.likes',
                '[data-votes]', '[data-score]', '[data-rating]'
            ].filter(Boolean);

            for (const selector of voteSelectors) {
                const voteElement = element.querySelector(selector);
                if (voteElement) {
                    const voteText = this.getCleanText(voteElement);
                    const numbers = voteText.match(/\d+/g);
                    return numbers ? numbers.map(n => parseInt(n)) : voteText;
                }
            }

            return null;
        },

        // Extract form data
        extractFormData: function(form) {
            const formData = {
                id: this.generateElementId(form),
                action: form.action || window.location.href,
                method: form.method || 'GET',
                fields: {},
                metadata: {
                    xpath: this.getXPath(form),
                    cssSelector: this.getCSSSelector(form)
                }
            };

            // Extract all form fields
            const elements = form.querySelectorAll('input, textarea, select');
            elements.forEach(element => {
                const name = element.name || element.id;
                if (name) {
                    let value = element.value;

                    if (element.type === 'checkbox' || element.type === 'radio') {
                        value = element.checked;
                    } else if (element.type === 'file') {
                        value = element.files ? Array.from(element.files).map(f => f.name) : null;
                    }

                    formData.fields[name] = value;
                }
            });

            return formData;
        },

        // Utility functions
        isRelevantForm: function(form) {
            if (!form || !form.tagName) return false;

            const formText = form.textContent.toLowerCase();
            const relevantKeywords = [
                'feedback', 'comment', 'response', 'consultation',
                'submit', 'opinion', 'review', 'suggestion'
            ];

            return relevantKeywords.some(keyword => formText.includes(keyword));
        },

        isRelevantRequest: function(url) {
            if (!url) return false;

            const urlLower = url.toLowerCase();
            const relevantPaths = [
                '/feedback', '/comment', '/response', '/consultation',
                '/api/feedback', '/api/comment', '/submit'
            ];

            return relevantPaths.some(path => urlLower.includes(path));
        },

        containsFeedbackData: function(data) {
            if (!data || typeof data !== 'object') return false;

            const dataStr = JSON.stringify(data).toLowerCase();
            const feedbackKeywords = [
                'feedback', 'comment', 'response', 'consultation',
                'opinion', 'review', 'suggestion'
            ];

            return feedbackKeywords.some(keyword => dataStr.includes(keyword));
        },

        findFeedbackElements: function(root) {
            const feedbackSelectors = [
                '.comment', '.feedback', '.response', '.review',
                '[data-comment]', '[data-feedback]', '[data-response]'
            ];

            const elements = [];
            feedbackSelectors.forEach(selector => {
                try {
                    root.querySelectorAll(selector).forEach(el => elements.push(el));
                } catch (e) {
                    // Invalid selector
                }
            });

            return elements;
        },

        serializeElement: function(element) {
            return {
                tagName: element.tagName,
                id: element.id,
                className: element.className,
                textContent: this.getCleanText(element).substring(0, 500),
                xpath: this.getXPath(element)
            };
        },

        isDuplicateComment: function(commentData) {
            const key = `${commentData.text.substring(0, 100)}_${commentData.author}`;

            if (this.extractedData.has(key)) {
                return true;
            }

            this.extractedData.add(key);
            return false;
        },

        getCleanText: function(element) {
            if (!element) return '';
            return element.textContent.trim().replace(/\s+/g, ' ');
        },

        generateElementId: function(element) {
            return 'elem_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        },

        getXPath: function(element) {
            if (element.id) {
                return `//*[@id="${element.id}"]`;
            }

            const path = [];
            while (element.nodeType === Node.ELEMENT_NODE) {
                let selector = element.nodeName.toLowerCase();

                if (element.previousElementSibling) {
                    let index = 1;
                    let sibling = element.previousElementSibling;
                    while (sibling) {
                        if (sibling.nodeName === element.nodeName) {
                            index++;
                        }
                        sibling = sibling.previousElementSibling;
                    }
                    selector += `[${index}]`;
                }

                path.unshift(selector);
                element = element.parentNode;
            }

            return '/' + path.join('/');
        },

        getCSSSelector: function(element) {
            if (element.id) {
                return '#' + element.id;
            }

            let selector = element.tagName.toLowerCase();

            if (element.className) {
                selector += '.' + element.className.split(' ').join('.');
            }

            return selector;
        },

        getElementPosition: function(element) {
            const rect = element.getBoundingClientRect();
            return {
                top: rect.top + window.scrollY,
                left: rect.left + window.scrollX,
                width: rect.width,
                height: rect.height
            };
        },

        getPageScripts: function() {
            const scripts = [];
            document.querySelectorAll('script[src]').forEach(script => {
                scripts.push(script.src);
            });
            return scripts;
        },

        checkForDynamicContent: function() {
            return {
                hasReact: !!window.React,
                hasVue: !!window.Vue,
                hasAngular: !!window.angular || !!window.ng,
                hasJQuery: !!window.jQuery || !!window.$,
                hasSPAFramework: !!(window.history && window.history.pushState)
            };
        },

        // Stop extraction and cleanup
        stopExtraction: function() {
            this.isActive = false;

            // Disconnect all observers
            this.observers.forEach(observer => observer.disconnect());
            this.observers = [];

            // Clear extracted data cache
            this.extractedData.clear();

            this.postMessage('EXTRACTION_STOPPED', { timestamp: Date.now() });
        }
    };

    // Auto-initialize
    FeedbackCollectorInject.init();

    // Export to global scope
    window.FeedbackCollectorInject = FeedbackCollectorInject;

})();
